# ------------------------------------
# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
# ------------------------------------

VERSION = "12.1.0a20260520003"  # type: str

SDK_MONIKER = "search-documents/{}".format(VERSION)  # type: str
